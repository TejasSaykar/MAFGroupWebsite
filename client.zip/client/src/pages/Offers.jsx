import React from 'react'
import Layout from '../components/Layout'

const Offers = () => {
  return (
    <Layout title={"Offers | MAF"}>
      <div className='mt-[4rem]'>
        offer
      </div>
    </Layout>
  )
}

export default Offers
