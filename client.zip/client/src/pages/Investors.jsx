import React from 'react'
import Layout from '../components/Layout'

const Investors = () => {
  return (
    <Layout title={"Investors | MAF"}>
      <div className='mt-[4rem]'>
        Investors Page
      </div>
    </Layout>
  )
}

export default Investors
