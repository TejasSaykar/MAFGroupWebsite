import React from 'react'
import Layout from '../components/Layout'

const Media = () => {
  return (
    <Layout>
      Media Page
    </Layout>
  )
}

export default Media
